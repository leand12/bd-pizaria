# Sistema de Gestão de Base de Dados do Sistema de Encomendas de uma Pizaria
### Projeto criado no âmbito da cadeira Base de Dados.
### Docente: Carlos Costa
### Membors: Leandro Silva e Mário Silva
#### Para mudar o utilizador da base de dados na SQLConnection, basta aceder ao ficheiro Program.cs dentro da pasta Interface.
#### O script de instalação, a apresentação e o demo da base de dados está na pasta principal.
