﻿namespace Pizaria
{
	partial class ClientMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button2 = new System.Windows.Forms.Button();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.label22 = new System.Windows.Forms.Label();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.dataGridView6 = new System.Windows.Forms.DataGridView();
			this.label2 = new System.Windows.Forms.Label();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label20 = new System.Windows.Forms.Label();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.button3 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button5 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.dataGridView4 = new System.Windows.Forms.DataGridView();
			this.button7 = new System.Windows.Forms.Button();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.button4 = new System.Windows.Forms.Button();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.button1 = new System.Windows.Forms.Button();
			this.dataGridView8 = new System.Windows.Forms.DataGridView();
			this.label19 = new System.Windows.Forms.Label();
			this.dataGridView5 = new System.Windows.Forms.DataGridView();
			this.label18 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.dataGridView3 = new System.Windows.Forms.DataGridView();
			this.dataGridView7 = new System.Windows.Forms.DataGridView();
			this.label13 = new System.Windows.Forms.Label();
			this.label21 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label12 = new System.Windows.Forms.Label();
			this.dataGridView2 = new System.Windows.Forms.DataGridView();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.label9 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tabControl4 = new System.Windows.Forms.TabControl();
			this.tabPage3.SuspendLayout();
			this.groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
			this.tabPage1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.tabControl4.SuspendLayout();
			this.SuspendLayout();
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.Firebrick;
			this.button2.ForeColor = System.Drawing.SystemColors.Menu;
			this.button2.Location = new System.Drawing.Point(1474, 43);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(111, 42);
			this.button2.TabIndex = 19;
			this.button2.Text = "Log out";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.label22);
			this.tabPage3.Controls.Add(this.textBox11);
			this.tabPage3.Controls.Add(this.groupBox4);
			this.tabPage3.Controls.Add(this.groupBox1);
			this.tabPage3.Controls.Add(this.textBox9);
			this.tabPage3.Controls.Add(this.label6);
			this.tabPage3.Controls.Add(this.button4);
			this.tabPage3.Location = new System.Drawing.Point(4, 29);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
			this.tabPage3.Size = new System.Drawing.Size(1420, 722);
			this.tabPage3.TabIndex = 1;
			this.tabPage3.Text = "Create Order";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label22.ForeColor = System.Drawing.Color.Red;
			this.label22.Location = new System.Drawing.Point(1196, 528);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(0, 20);
			this.label22.TabIndex = 55;
			// 
			// textBox11
			// 
			this.textBox11.Location = new System.Drawing.Point(1034, 557);
			this.textBox11.Name = "textBox11";
			this.textBox11.ReadOnly = true;
			this.textBox11.Size = new System.Drawing.Size(157, 26);
			this.textBox11.TabIndex = 54;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.dataGridView6);
			this.groupBox4.Controls.Add(this.label2);
			this.groupBox4.Controls.Add(this.textBox2);
			this.groupBox4.Controls.Add(this.label20);
			this.groupBox4.Controls.Add(this.dateTimePicker2);
			this.groupBox4.Controls.Add(this.textBox1);
			this.groupBox4.Controls.Add(this.button3);
			this.groupBox4.Controls.Add(this.button6);
			this.groupBox4.Controls.Add(this.label8);
			this.groupBox4.Controls.Add(this.label7);
			this.groupBox4.Controls.Add(this.dateTimePicker1);
			this.groupBox4.Controls.Add(this.label4);
			this.groupBox4.Controls.Add(this.comboBox1);
			this.groupBox4.Controls.Add(this.label5);
			this.groupBox4.Location = new System.Drawing.Point(26, 28);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(782, 460);
			this.groupBox4.TabIndex = 53;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Order";
			// 
			// dataGridView6
			// 
			this.dataGridView6.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView6.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView6.Location = new System.Drawing.Point(30, 57);
			this.dataGridView6.Name = "dataGridView6";
			this.dataGridView6.RowHeadersWidth = 62;
			this.dataGridView6.RowTemplate.Height = 28;
			this.dataGridView6.Size = new System.Drawing.Size(405, 323);
			this.dataGridView6.TabIndex = 66;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(456, 288);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 20);
			this.label2.TabIndex = 65;
			this.label2.Text = "Discount";
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(459, 309);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(157, 26);
			this.textBox2.TabIndex = 64;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(456, 212);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(43, 20);
			this.label20.TabIndex = 63;
			this.label20.Text = "Time";
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.CustomFormat = "yyyy/mm/dd";
			this.dateTimePicker2.Location = new System.Drawing.Point(459, 157);
			this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.Size = new System.Drawing.Size(290, 26);
			this.dateTimePicker2.TabIndex = 62;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(459, 77);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(290, 26);
			this.textBox1.TabIndex = 58;
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(590, 386);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(160, 45);
			this.button3.TabIndex = 32;
			this.button3.Text = "Clear All";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(96, 386);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(273, 45);
			this.button6.TabIndex = 61;
			this.button6.Text = "Edit Shop Cart";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(456, 54);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(68, 20);
			this.label8.TabIndex = 59;
			this.label8.Text = "Address";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(456, 128);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(44, 20);
			this.label7.TabIndex = 57;
			this.label7.Text = "Date";
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.CustomFormat = "yyyy/m/ hh:mm";
			this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker1.Location = new System.Drawing.Point(459, 237);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.ShowUpDown = true;
			this.dateTimePicker1.Size = new System.Drawing.Size(127, 26);
			this.dateTimePicker1.TabIndex = 56;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(603, 212);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(129, 20);
			this.label4.TabIndex = 55;
			this.label4.Text = "Payment Method";
			// 
			// comboBox1
			// 
			this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "Card",
            "Cash"});
			this.comboBox1.Location = new System.Drawing.Point(608, 235);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(142, 28);
			this.comboBox1.TabIndex = 54;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(26, 34);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(81, 20);
			this.label5.TabIndex = 53;
			this.label5.Text = "Shop Cart";
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.button5);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.dataGridView4);
			this.groupBox1.Controls.Add(this.button7);
			this.groupBox1.Location = new System.Drawing.Point(830, 28);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(542, 460);
			this.groupBox1.TabIndex = 49;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Discounts";
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(285, 386);
			this.button5.Margin = new System.Windows.Forms.Padding(0);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(147, 45);
			this.button5.TabIndex = 69;
			this.button5.Text = "Clear Discount";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(22, 31);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(147, 20);
			this.label3.TabIndex = 68;
			this.label3.Text = "Available Discounts";
			// 
			// dataGridView4
			// 
			this.dataGridView4.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView4.Location = new System.Drawing.Point(26, 54);
			this.dataGridView4.Name = "dataGridView4";
			this.dataGridView4.RowHeadersWidth = 62;
			this.dataGridView4.RowTemplate.Height = 28;
			this.dataGridView4.Size = new System.Drawing.Size(490, 323);
			this.dataGridView4.TabIndex = 67;
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(116, 386);
			this.button7.Margin = new System.Windows.Forms.Padding(0);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(147, 45);
			this.button7.TabIndex = 47;
			this.button7.Text = "Use Discount";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(1034, 525);
			this.textBox9.Name = "textBox9";
			this.textBox9.ReadOnly = true;
			this.textBox9.Size = new System.Drawing.Size(157, 26);
			this.textBox9.TabIndex = 48;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(976, 528);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 20);
			this.label6.TabIndex = 35;
			this.label6.Text = "Total:";
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(1004, 623);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(190, 45);
			this.button4.TabIndex = 31;
			this.button4.Text = "Finish Order";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.groupBox3);
			this.tabPage2.Location = new System.Drawing.Point(4, 29);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Size = new System.Drawing.Size(1420, 722);
			this.tabPage2.TabIndex = 2;
			this.tabPage2.Text = "My Orders";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.label10);
			this.groupBox3.Controls.Add(this.textBox10);
			this.groupBox3.Controls.Add(this.button1);
			this.groupBox3.Controls.Add(this.dataGridView8);
			this.groupBox3.Controls.Add(this.label19);
			this.groupBox3.Controls.Add(this.dataGridView5);
			this.groupBox3.Controls.Add(this.label18);
			this.groupBox3.Controls.Add(this.label17);
			this.groupBox3.Controls.Add(this.label16);
			this.groupBox3.Controls.Add(this.label15);
			this.groupBox3.Controls.Add(this.label14);
			this.groupBox3.Controls.Add(this.textBox8);
			this.groupBox3.Controls.Add(this.textBox7);
			this.groupBox3.Controls.Add(this.textBox6);
			this.groupBox3.Controls.Add(this.textBox5);
			this.groupBox3.Location = new System.Drawing.Point(80, 23);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(1218, 637);
			this.groupBox3.TabIndex = 22;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Orders";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(903, 108);
			this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(99, 20);
			this.label10.TabIndex = 32;
			this.label10.Text = "Order\'s Price";
			// 
			// textBox10
			// 
			this.textBox10.Location = new System.Drawing.Point(903, 138);
			this.textBox10.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox10.Name = "textBox10";
			this.textBox10.ReadOnly = true;
			this.textBox10.Size = new System.Drawing.Size(109, 26);
			this.textBox10.TabIndex = 31;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(480, 495);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(256, 85);
			this.button1.TabIndex = 0;
			this.button1.Text = "Show Past Orders";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// dataGridView8
			// 
			this.dataGridView8.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView8.Location = new System.Drawing.Point(330, 83);
			this.dataGridView8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.dataGridView8.Name = "dataGridView8";
			this.dataGridView8.RowHeadersWidth = 62;
			this.dataGridView8.Size = new System.Drawing.Size(290, 311);
			this.dataGridView8.TabIndex = 30;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(326, 58);
			this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(104, 20);
			this.label19.TabIndex = 28;
			this.label19.Text = "Order\'s Items";
			// 
			// dataGridView5
			// 
			this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView5.Location = new System.Drawing.Point(38, 83);
			this.dataGridView5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.dataGridView5.Name = "dataGridView5";
			this.dataGridView5.RowHeadersWidth = 62;
			this.dataGridView5.Size = new System.Drawing.Size(228, 311);
			this.dataGridView5.TabIndex = 29;
			this.dataGridView5.SelectionChanged += new System.EventHandler(this.dataGridView5_SelectionChanged);
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(33, 58);
			this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(102, 20);
			this.label18.TabIndex = 27;
			this.label18.Text = "Delivery Time";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(681, 298);
			this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(149, 20);
			this.label17.TabIndex = 25;
			this.label17.Text = "Delivery Destination";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(903, 195);
			this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(112, 20);
			this.label16.TabIndex = 24;
			this.label16.Text = "Courier\'s email";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(686, 195);
			this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(128, 20);
			this.label15.TabIndex = 23;
			this.label15.Text = "Courier\'s contact";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(681, 108);
			this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(115, 20);
			this.label14.TabIndex = 22;
			this.label14.Text = "Courier\'s name";
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(681, 323);
			this.textBox8.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox8.Name = "textBox8";
			this.textBox8.ReadOnly = true;
			this.textBox8.Size = new System.Drawing.Size(412, 26);
			this.textBox8.TabIndex = 21;
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(903, 226);
			this.textBox7.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox7.Name = "textBox7";
			this.textBox7.ReadOnly = true;
			this.textBox7.Size = new System.Drawing.Size(290, 26);
			this.textBox7.TabIndex = 20;
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(681, 225);
			this.textBox6.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox6.Name = "textBox6";
			this.textBox6.ReadOnly = true;
			this.textBox6.Size = new System.Drawing.Size(194, 26);
			this.textBox6.TabIndex = 19;
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(681, 137);
			this.textBox5.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox5.Name = "textBox5";
			this.textBox5.ReadOnly = true;
			this.textBox5.Size = new System.Drawing.Size(194, 26);
			this.textBox5.TabIndex = 18;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.dataGridView3);
			this.tabPage1.Controls.Add(this.dataGridView7);
			this.tabPage1.Controls.Add(this.label13);
			this.tabPage1.Controls.Add(this.label21);
			this.tabPage1.Controls.Add(this.groupBox2);
			this.tabPage1.Controls.Add(this.dataGridView2);
			this.tabPage1.Controls.Add(this.dataGridView1);
			this.tabPage1.Controls.Add(this.pictureBox2);
			this.tabPage1.Controls.Add(this.label9);
			this.tabPage1.Controls.Add(this.label1);
			this.tabPage1.Location = new System.Drawing.Point(4, 29);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 3, 3, 3);
			this.tabPage1.Size = new System.Drawing.Size(1420, 722);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Main";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// dataGridView3
			// 
			this.dataGridView3.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView3.Location = new System.Drawing.Point(720, 62);
			this.dataGridView3.Name = "dataGridView3";
			this.dataGridView3.RowHeadersWidth = 62;
			this.dataGridView3.RowTemplate.Height = 28;
			this.dataGridView3.Size = new System.Drawing.Size(310, 449);
			this.dataGridView3.TabIndex = 44;
			this.dataGridView3.SelectionChanged += new System.EventHandler(this.dataGridView3_SelectionChanged);
			// 
			// dataGridView7
			// 
			this.dataGridView7.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView7.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView7.Location = new System.Drawing.Point(1036, 62);
			this.dataGridView7.Name = "dataGridView7";
			this.dataGridView7.RowHeadersWidth = 62;
			this.dataGridView7.RowTemplate.Height = 28;
			this.dataGridView7.Size = new System.Drawing.Size(352, 323);
			this.dataGridView7.TabIndex = 43;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(1032, 38);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(89, 60);
			this.label13.TabIndex = 42;
			this.label13.Text = "Ingredients\r\n\r\n\r\n";
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(716, 38);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(55, 20);
			this.label21.TabIndex = 41;
			this.label21.Text = "Pizzas";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.textBox3);
			this.groupBox2.Controls.Add(this.label11);
			this.groupBox2.Controls.Add(this.textBox4);
			this.groupBox2.Controls.Add(this.label12);
			this.groupBox2.Location = new System.Drawing.Point(358, 563);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(538, 120);
			this.groupBox2.TabIndex = 40;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Filters";
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(36, 60);
			this.textBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(148, 26);
			this.textBox3.TabIndex = 33;
			this.textBox3.TextChanged += new System.EventHandler(this.textBox3and4_TextChanged);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(32, 35);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(77, 20);
			this.label11.TabIndex = 35;
			this.label11.Text = "Max Price";
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(310, 60);
			this.textBox4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(148, 26);
			this.textBox4.TabIndex = 34;
			this.textBox4.TextChanged += new System.EventHandler(this.textBox3and4_TextChanged);
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(308, 35);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(51, 20);
			this.label12.TabIndex = 36;
			this.label12.Text = "Name";
			// 
			// dataGridView2
			// 
			this.dataGridView2.AllowUserToResizeRows = false;
			this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView2.Location = new System.Drawing.Point(26, 62);
			this.dataGridView2.Name = "dataGridView2";
			this.dataGridView2.RowHeadersWidth = 62;
			this.dataGridView2.RowTemplate.Height = 28;
			this.dataGridView2.Size = new System.Drawing.Size(310, 449);
			this.dataGridView2.TabIndex = 39;
			this.dataGridView2.SelectionChanged += new System.EventHandler(this.dataGridView2_SelectionChanged);
			// 
			// dataGridView1
			// 
			this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Location = new System.Drawing.Point(340, 62);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.RowHeadersWidth = 62;
			this.dataGridView1.RowTemplate.Height = 28;
			this.dataGridView1.Size = new System.Drawing.Size(352, 323);
			this.dataGridView1.TabIndex = 38;
			// 
			// pictureBox2
			// 
			this.pictureBox2.BackColor = System.Drawing.Color.Silver;
			this.pictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pictureBox2.Location = new System.Drawing.Point(1036, 392);
			this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(352, 275);
			this.pictureBox2.TabIndex = 32;
			this.pictureBox2.TabStop = false;
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(338, 38);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(72, 20);
			this.label9.TabIndex = 28;
			this.label9.Text = "Products";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(21, 38);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(57, 20);
			this.label1.TabIndex = 23;
			this.label1.Text = "Menus";
			// 
			// tabControl4
			// 
			this.tabControl4.Controls.Add(this.tabPage1);
			this.tabControl4.Controls.Add(this.tabPage2);
			this.tabControl4.Controls.Add(this.tabPage3);
			this.tabControl4.Location = new System.Drawing.Point(14, 14);
			this.tabControl4.Name = "tabControl4";
			this.tabControl4.SelectedIndex = 0;
			this.tabControl4.Size = new System.Drawing.Size(1428, 755);
			this.tabControl4.TabIndex = 20;
			// 
			// ClientMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1617, 782);
			this.Controls.Add(this.button2);
			this.Controls.Add(this.tabControl4);
			this.Name = "ClientMain";
			this.Text = "ClientMain";
			this.Load += new System.EventHandler(this.ClientMain_Load);
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView6)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView8)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView7)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.tabControl4.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabControl tabControl4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
		private System.Windows.Forms.DataGridView dataGridView3;
		private System.Windows.Forms.DataGridView dataGridView7;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.DataGridView dataGridView6;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.DataGridView dataGridView8;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.Button button5;
	}
}